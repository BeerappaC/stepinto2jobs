package xxx.just;

import java.io.IOException;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class Blob
 */
@WebServlet("/Blob")
@MultipartConfig(maxFileSize=16177215)
public class Blob extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Connection con=null;
		PreparedStatement ps=null;
		int result=0;
		Part ui=req.getPart("ui");
		Part resume=req.getPart("res");
		if(ui!=null&&res!=null){
		try {
			String sql="insert into bblob values(?,?,?)";
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root","root");
			System.out.println("Database Connection Established");
			String sid=req.getParameter("id");
			int id=Integer.parseInt(sid);
			InputStream is=ui.getInputStream();
			
			InputStream iss=resume.getInputStream();
			ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setBinaryStream(2,is);
			ps.setBinaryStream(3,iss);
			result=ps.executeUpdate();
			System.out.println("Data Inserted");
			/*RequestDispatcher rd=req.getRequestDispatcher("Experience.jsp");
			rd.include(req, res);*/
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally{
			if(ps!=null){
				try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
			if(con!=null){
				try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
		if(result>0){
			res.sendRedirect("blob.jsp");}
		else{
			res.sendRedirect("Error Occured");
		}
		}
	}

}
