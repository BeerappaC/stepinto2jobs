 package com.wexos.Company;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Company")
public class Company extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
			Connection con=null;
			PreparedStatement pstmt=null;
			String sql="insert into stepin2.company values(?,?,?,?,?,?)";
			System.out.println("Query Executed");
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
				System.out.println("DB Connection Successfully");
				String sid=req.getParameter("id");
				int id=Integer.parseInt(sid);
				String cname=req.getParameter("cname");
				String pdesc=req.getParameter("pdes");
				System.out.println(pdesc);
				String bstream=req.getParameter("bstream");
				String sedate=req.getParameter("sedate");
				Date edate=Date.valueOf(sedate);
				String cweb=req.getParameter("cweb");
				pstmt=con.prepareStatement(sql);
				pstmt.setInt(1,id);
				pstmt.setString(2, cname);
				pstmt.setString(3,pdesc);
				pstmt.setString(4,bstream);
				pstmt.setDate(5,edate);
				pstmt.setString(6,cweb);
				pstmt.executeUpdate();
				System.out.println("DB Elements Inserted");
				req.getRequestDispatcher("address.jsp").forward(req, res);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}finally{
				if(pstmt!=null){
					try {
						pstmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if(con!=null){
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
   }
