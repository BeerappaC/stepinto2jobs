package com.wexos.Company.HRForm;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HRForm")
public class HRForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String sid=req.getParameter("id");
		int id=Integer.parseInt(sid);
		String name=req.getParameter("nm");
		String email=req.getParameter("email");
		String dept=req.getParameter("dept");
		String scomp=req.getParameter("comp"); 
		int comp=Integer.parseInt(scomp);
		Connection con=null;
		PreparedStatement pstmt=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
			System.out.println("DB Connection Successfully");
			String sql="insert into stepin2.hr values(?,?,?,?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,id);
			pstmt.setString(2,name);
			pstmt.setString(3,email);
			pstmt.setString(4,dept);
			pstmt.setInt(5,comp);
			pstmt.executeUpdate();
			System.out.println("Data Successfully Entered");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally{
			if(pstmt!=null){try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}}
			if(con!=null){try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}}
		}
	}

}
