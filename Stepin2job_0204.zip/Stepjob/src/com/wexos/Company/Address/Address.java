package com.wexos.Company.Address;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Address")
public class Address extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Connection con=null;
		PreparedStatement pstmt=null;
		String sql="insert into stepin2.address values(?,?,?,?,?,?,?)";
		System.out.println("Query Executed");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
			System.out.println("DB Connection Successfully");
			String sid=req.getParameter("id");
			int id=Integer.parseInt(sid);
			String area=req.getParameter("area");
			String city=req.getParameter("city");
			String state=req.getParameter("state");
			String country=req.getParameter("country");
			String pin=req.getParameter("pin");
			String type=req.getParameter("type");
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.setString(2,area);
			pstmt.setString(3,city);
			pstmt.setString(4,state);
			pstmt.setString(5,country);
			pstmt.setString(6,pin);
			pstmt.setString(7,type);
			pstmt.executeUpdate();
			req.getRequestDispatcher("branch.jsp").forward(req, res);
			System.out.println("DB Elements Inserted");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null){
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(con!=null){
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
