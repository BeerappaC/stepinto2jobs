package com.wexos.Company.Branch;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Branch
 */
@WebServlet("/Branch")
public class Branch extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Connection con=null;
		PreparedStatement pstmt=null;
		String sql="insert into stepin2.branch values(?,?)";
		System.out.println("Query Executed");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
			System.out.println("DB Connection Successfully");
			String scid=req.getParameter("cid");
			int cid=Integer.parseInt(scid);
			String name=req.getParameter("name");
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, cid);
			pstmt.setString(2,name);
			pstmt.executeUpdate();
			System.out.println("DB Elements Inserted");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null){
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(con!=null){
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
