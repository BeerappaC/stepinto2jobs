package com.wexos.JobPost;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class JobPostServlet
 */
@WebServlet("/JobPostServlet")
public class JobPostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobPostServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pstmt=null;
		System.out.println("Entered");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stepin2","root","root");
			System.out.println("DataBase Connection Established ");
			String sql="insert into job_post values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			pstmt=con.prepareStatement(sql);
			String sid=req.getParameter("id");
			int id=Integer.parseInt(sid);
			String title=req.getParameter("title");
			String des=req.getParameter("des");
			String svac=req.getParameter("vac");
			int vac=Integer.parseInt(svac);
			String exp=req.getParameter("exp");
			String ctc=req.getParameter("ctc");
			String loc=req.getParameter("loc");
			String fa=req.getParameter("fa");
			String qua=req.getParameter("qua");
			String ji=req.getParameter("ji");
			String jt=req.getParameter("jt");
			String swd=req.getParameter("wd");
			Date wd=Date.valueOf(swd);
			String ven=req.getParameter("ven");
			String cp=req.getParameter("cp");
			String cpn=req.getParameter("cpn");
			String cpe=req.getParameter("cpe");
			String web=req.getParameter("web");
			String sdp=req.getParameter("dp");
			Date dp=Date.valueOf(sdp);
			
			pstmt.setInt(1,id);
			System.out.println("1 Elements Entered");
			pstmt.setInt(1, id);
			pstmt.setString(2, title);
			pstmt.setString(3, des);
			pstmt.setInt(4, vac);
			pstmt.setString(5, exp);
			System.out.println("5 Elements Entered");
			pstmt.setString(6, ctc);
			pstmt.setString(7, loc);
			pstmt.setString(8, fa);
			pstmt.setString(9, qua);
			pstmt.setString(10, ji);
			System.out.println("10 Elements Entered");
			pstmt.setString(11, jt);
			pstmt.setDate(12, wd);
			pstmt.setString(13, ven);
			pstmt.setString(14, cp);
			pstmt.setString(15, cpn);
			pstmt.setString(16, cpe);
			pstmt.setString(17, web);
			pstmt.setDate(18,dp);
			pstmt.executeUpdate();
			System.out.println("Data Inserted Successfully");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally{
			if(pstmt!=null){try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}}
			if(con!=null){try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}}
		}
		
	
	}

	

}
