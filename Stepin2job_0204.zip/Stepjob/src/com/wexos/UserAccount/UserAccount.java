package com.wexos.UserAccount;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UserAccount
 */
@MultipartConfig
@WebServlet("/UserAccount")
public class UserAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Connection con=null;
		PreparedStatement ps=null;
		try {
			String sql="insert into user_account values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stepin2","root","root");
			System.out.println("Database Connection Established");
			int id = Integer.parseInt(req.getParameter("id"));
			System.out.println("ID Inserted");
			String fn=req.getParameter("fn");
			String ln=req.getParameter("ln");
			String fan=req.getParameter("fan");
			String mon=req.getParameter("mon");
			String email=req.getParameter("email");
			String pwd=req.getParameter("pwd");
			String sdob=req.getParameter("dob");
			Date dob=Date.valueOf(sdob);
			String Gender=req.getParameter("Gender");
			String cn=req.getParameter("cn");
			Part ui=req.getPart("ui");
			InputStream is=ui.getInputStream();
			Date regdate=Date.valueOf(LocalDate.now());
			Part re=req.getPart("res");
			InputStream iss=re.getInputStream();
			System.out.println("Images Inserted");
			String blood=req.getParameter("blood");
			int age = Integer.parseInt(req.getParameter("age"));
			System.out.println("Age Inserted");
			ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2,fn);
			ps.setString(3,ln);
			ps.setString(4,fan);
			ps.setString(5,mon);
			ps.setString(6,email);
			ps.setString(7,pwd);
			ps.setDate(8,dob);
			ps.setString(9,Gender);
			ps.setString(10,cn);
			ps.setBlob(11,is);
			ps.setDate(12,regdate);
			ps.setBlob(13,iss);
			ps.setString(14,blood);
			ps.setInt(15, age);
			ps.executeUpdate();
			System.out.println("Data Inserted");
			/*RequestDispatcher rd=req.getRequestDispatcher("Experience.jsp");
			rd.include(req, res);*/
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally{
			if(ps!=null){
				try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
			if(con!=null){
				try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		}
	}

}
